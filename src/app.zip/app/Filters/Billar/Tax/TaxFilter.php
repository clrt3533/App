<?php


namespace App\Filters\Billar\Tax;


use App\Filters\Billar\Traits\NameFilterTrait;
use App\Filters\FilterBuilder;

class TaxFilter extends FilterBuilder
{
    use NameFilterTrait;
}