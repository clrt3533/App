<?php


namespace App\Models\Core\File\Traits;


trait FileMethod
{

}
