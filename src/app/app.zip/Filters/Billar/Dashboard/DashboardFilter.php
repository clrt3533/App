<?php

namespace App\Filters\Billar\Dashboard;

use App\Filters\Core\BaseFilter;
use App\Models\Billar\Traits\IndividualClientTrait;

class DashboardFilter extends BaseFilter
{
  use IndividualClientTrait;
}