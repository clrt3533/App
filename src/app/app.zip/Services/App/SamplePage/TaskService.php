<?php

namespace App\Services\App\SamplePage;


use App\Services\App\AppService;

class TaskService extends AppService
{


}
