<template>

</template>

<script>
export default {
    name: "SendQuotationModal"
}
</script>

<style scoped>

</style>