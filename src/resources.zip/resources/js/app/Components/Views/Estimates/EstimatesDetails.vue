<template>

</template>

<script>
export default {
    name: "Quotationdetails"
}
</script>

<style scoped>

</style>