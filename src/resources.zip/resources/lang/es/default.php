<?php
return array_merge([
    // Responses

    'Jan' => 'Enero',
    'Feb' => 'Febrero',
    'Mar' => 'Marzo',
    'Apr' => 'Abril',
    'May' => 'Mayo',
    'Jun' => 'Junio',
    'Jul' => 'Julio',
    'Aug' => 'Agosto',
    'Sep' => 'Septiembre',
    'Oct' => 'Octubre',
    'Nov' => 'Noviembre',
    'Dec' => 'Diciembre',
    'my_profile' => 'Profila',
    'notifications' => 'Notificationa',
    'logout' => 'Logoutaaaa'


], include 'custom.php');
