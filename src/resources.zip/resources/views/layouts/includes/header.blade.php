@stack('before-styles')
{{ style(mix('css/dropzone.css')) }}
{{ style(mix('css/core.css')) }}
{{ style(mix('css/fontawesome.css')) }}
{{ style('vendor/summernote/summernote-bs4.css') }}
@stack('after-styles')
