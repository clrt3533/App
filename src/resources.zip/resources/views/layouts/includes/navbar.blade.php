<app-top-bar :logo="{{json_encode(config('settings.application.company_icon'))}}"></app-top-bar>
