@extends('layouts.app')

@section('title', trans('default.dashboard'))

@section('contents')
    <dashboard></dashboard>
@endsection

