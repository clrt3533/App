@extends('layouts.app')

@section('title', trans('default.app_settings'))

@section('contents')
    <app-setting></app-setting>
@endsection

