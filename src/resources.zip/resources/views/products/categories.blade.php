@extends('layouts.app')

@section('title', trans('default.categories'))

@section('contents')
    <categories></categories>
@endsection

