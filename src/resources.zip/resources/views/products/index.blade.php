@extends('layouts.app')

@section('title', trans('default.products'))

@section('contents')
    <products></products>
@endsection

