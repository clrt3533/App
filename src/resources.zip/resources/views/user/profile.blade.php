@extends('layouts.app')

@section('title', trans('default.profile'))

@section('contents')
    <my-profile></my-profile>
@endsection
