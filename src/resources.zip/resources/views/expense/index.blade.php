@extends('layouts.app')

@section('title', trans('default.expenses'))

@section('contents')
    <app-expense></app-expense>
@endsection
