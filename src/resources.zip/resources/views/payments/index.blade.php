@extends('layouts.app')

@section('title', trans('default.payments'))

@section('contents')
    <payments></payments>
@endsection

