@extends('layouts.app')

@section('title', trans('default.clients'))

@section('contents')
    <clients></clients>
@endsection

