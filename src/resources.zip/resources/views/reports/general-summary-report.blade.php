@extends('layouts.app')

@section('title', trans('default.general_summary'))

@section('contents')
    <general-summary-report></general-summary-report>
@endsection

