@extends('layouts.app')

@section('title', trans('default.expense_report'))

@section('contents')
    <expense-report></expense-report>
@endsection

