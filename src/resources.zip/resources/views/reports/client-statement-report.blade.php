@extends('layouts.app')

@section('title', trans('default.client_statement'))

@section('contents')
    <client-statement-report></client-statement-report>
@endsection

