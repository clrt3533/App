@extends('layouts.app')

@section('title', trans('default.invoice_report'))

@section('contents')
    <invoice-report></invoice-report>
@endsection

