@extends('layouts.app')

@section('title', trans('default.payments_summary'))

@section('contents')
    <payment-summary-report></payment-summary-report>
@endsection

