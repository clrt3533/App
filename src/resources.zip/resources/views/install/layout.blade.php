@extends('install.master')

@section('master')
    <div class="container">
        @yield('contents')
    </div>
@endsection
