@extends('layouts.app')

@section('title', trans('default.purposes'))

@section('contents')
    <app-purposes></app-purposes>
@endsection

