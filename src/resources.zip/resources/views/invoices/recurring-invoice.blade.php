@extends('layouts.app')

@section('title', trans('default.recurring_invoices'))

@section('contents')
    <recurring-invoice-list></recurring-invoice-list>
@endsection

