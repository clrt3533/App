{!! $template !!}
