@extends('layouts.app')

@section('title', trans('default.estimates'))

@section('contents')
    <app-estimates></app-estimates>
@endsection

