<h4>Invoice Number {{$payment->invoice_number}}</h4>
<h4>Total {{$payment->total}}</h4>